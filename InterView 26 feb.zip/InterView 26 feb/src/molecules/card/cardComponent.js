import React from 'react'
import FooterComponent from '../../components/footer/footer'
import './cardComponent.css'
const CardComponent = ({ backgroundColor, pannel, title, titleValue, buttonColor, onClick, buttonText }) => {
    return <div className="card card-wrapper" style={{ backgroundColor: backgroundColor }}>

        <p>{pannel}</p>
        <div className="to-display">
            <div> {title} : {titleValue}</div>
            <div className="buttonx"><button style={{ "backgroundColor": { buttonColor } }} onClick={onClick}>{buttonText}</button></div>
        </div>

    </div>
}

export default CardComponent