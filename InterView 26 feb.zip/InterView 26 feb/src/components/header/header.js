import React from 'react'
import './header.css'
const HeaderComponent=()=>{
    return <header className="header-wrapper">
        <div className="title"> 
            Application  Dashboard
        </div>
        <div className="profile"> 
            <span>Home/Dashboard</span>
            <span className="name">Vikash Gupta</span>
        </div>
    </header>
}

export default  HeaderComponent;