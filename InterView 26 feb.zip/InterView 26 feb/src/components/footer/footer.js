import { getDefaultNormalizer } from '@testing-library/react';
import React from 'react';
import './footer.css'
const FooterComponent=()=>{
    return <div className="footer-wrapper">
         @copyright 2021
    </div>
}

export default FooterComponent;