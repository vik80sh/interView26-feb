import React from 'react';
import HeaderComponent from './components/header/header'
import FooterComponent from './components/footer/footer';
import data from './constant'
import './App.css'
import CardComponent from './molecules/card/cardComponent';
function App() {
  const onClickHandler = (data) => {
    console.log(data)
  }
  return (
    <div className="container-fluid">
      <HeaderComponent />
      
      <div className="row">
        <div className="col-xs-6 col-sm-6 ">
          <CardComponent
            backgroundColor={data[0].backGroundColor}
            pannel={data[0].pannel}
            title="Annual Profit"
            titleValue={data[0].profit}
            buttonColor={data[0].buttonColor}
            onClick={() => onClickHandler(data[0].pannel)}
            buttonText={data[0].buttonText}
          />
        </div>
        <div className="col-xs-6 col-sm-6 ">
          <CardComponent
            backgroundColor={data[1].backGroundColor}
            pannel={data[1].pannel}
            title="Annual Profit"
            titleValue={data[1].profit}
            buttonColor={data[1].buttonColor}
            onClick={() => onClickHandler(data[1].pannel)}
            buttonText={data[1].buttonText}
          />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-6 col-sm-6">
          <CardComponent
            backgroundColor={data[2].backGroundColor}
            pannel={data[2].pannel}
            title="Annual Profit"
            titleValue={data[2].profit}
            buttonColor={data[2].buttonColor}
            onClick={() => onClickHandler(data[2].pannel)}
            buttonText={data[2].buttonText}
          />
        </div>
        <div className="col-xs-6 col-sm-6">
          <CardComponent
            backgroundColor={data[3].backGroundColor}
            pannel={data[3].pannel}
            title="Annual Profit"
            titleValue={data[3].profit}
            buttonColor={data[3].buttonColor}
            onClick={() => onClickHandler(data[3].pannel)}
            buttonText={data[3].buttonText}
          />
        </div>
      </div>
      <FooterComponent />
    </div >
  );
}

export default App;