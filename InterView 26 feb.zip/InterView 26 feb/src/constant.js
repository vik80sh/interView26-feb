const data=[
    {
        pannel :"Pannel1",
        profit:"$87889.00",
        buttonText:"Log Profit",
        buttonColor:"green",
        backGroundColor:"white"
    },
    {
        pannel:"Pannel2",
        profit:"$12900.0",
        buttonText:"Find Income",
        buttonColor:"white",
        backGroundColor:"white"
    },
    {
        pannel:"Pannel1",
        profit:"635533",
        buttonText:"All Customers",
        buttonColor:"green",
        backGroundColor:"green"
    },
    {
        pannel:"Pannel2",
        profit:"12333",
        buttonText:"Find Income",
        buttonColor:"green",
        backGroundColor:"#1adbc0"
    }
]

export default data
